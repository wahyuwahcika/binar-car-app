import React from "react";
import Ticket from "../components/Ticket";

const ETicket = () => {
  return (
    <>
      <Ticket />
    </>
  );
};

export default ETicket;
