import React from "react";
import BankPayment from "../components/BankPayment";

const BankConfirm = () => {
  return (
    <>
      <BankPayment />
    </>
  );
};

export default BankConfirm;
