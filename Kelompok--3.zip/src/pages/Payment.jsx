import React from "react";
import PaymentDesc from "../components/PaymentDesc";

const Payment = () => {
  return (
    <>
      <PaymentDesc />
    </>
  );
};

export default Payment;
