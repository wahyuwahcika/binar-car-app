import React from "react";
import "../assets/css/GreyArea.css";

const Greyarea = () => {
  return <div className="greyarea"></div>;
};

export default Greyarea;
