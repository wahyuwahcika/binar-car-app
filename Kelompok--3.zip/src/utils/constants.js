const CONST = {
  API_BASE_URL: `https://bootcamp-rent-cars.herokuapp.com/customer`,
};

export default CONST;
